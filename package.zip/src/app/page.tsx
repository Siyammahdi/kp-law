"use client";
import React, { useState } from "react";
import { LiaUserShieldSolid } from "react-icons/lia";
import { Formik, FormikHelpers } from "formik";
import Step1 from "@/Components/Steps/Step1";
import Step2 from "@/Components/Steps/Step2";

interface FormValues {
  firstname: string;
  lastname: string;
  email: string;
  phone: string;
  address: string;
  country: string;
  dobDay: string;
  dobMonth: string;
  dobYear: string;
  capacity: string;
  diagnosisYear: string;
  hearAboutUs: string;
  terms: boolean;
}

const initialValues: FormValues = {
  firstname: "",
  lastname: "",
  email: "",
  phone: "",
  address: "",
  country: "",
  dobDay: "",
  dobMonth: "",
  dobYear: "",
  capacity: "",
  diagnosisYear: "",
  hearAboutUs: "",
  terms: false,
};

const Page: React.FC = () => {
  const [step, setStep] = useState(0);

  const handleSubmit = (values: FormValues, actions: FormikHelpers<FormValues>) => {
    console.log("Form data:", values);
    actions.setSubmitting(false);
  };

  return (
    <Formik initialValues={initialValues} onSubmit={handleSubmit}>
      {({ handleSubmit }) => (
        <div>
          {step === 0 ? <Step1 /> : <Step2 />}
          <div className="max-w-6xl lg:mx-auto mx-5">
            <div className="bg-button bg-opacity-10 border border-button w-full text-button rounded-xl py-4 px-4">
              <p className="flex items-center">
                <span className="text-3xl mr-4">
                  <LiaUserShieldSolid />
                </span>
                Your information is kept secure and confidential at all times.
              </p>
            </div>
            <button
              onClick={() => {
                // if (step === 0) {
                //   setStep(1);
                // } else {
                //   handleSubmit();
                // }
                handleSubmit()
              }}
              className="bg-button w-full text-white rounded-xl text-xl py-3 my-8 px-4"
            >
              {step === 0 ? "Next" : "Accept"}
            </button>
          </div>
        </div>
      )}
    </Formik>
  );
};

export default Page;
